script_info = {
	["title"] = "删除关键词",
	["description"] = "",
	["version"] = "0.0.1",
	["tooltip"] = "",
	["edit_count"] = "1",
	["edit_tips"] = "关键字",
}

function onRename(file, input)
	local i, j = string.find(file.name, input[1], 1, true)
	if i then
		file.name = string.sub(file.name, 1, i - 1) .. string.sub(file.name, j + 1)
	end
	return file.name
end