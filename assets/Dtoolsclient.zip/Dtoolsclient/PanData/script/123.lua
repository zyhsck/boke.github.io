local curl = require "lcurl.safe"
local json = require "cjson.safe"
script_info = {
 ["title"] = "51破jie",
    ["description"] = "侵删",
    ["version"] = "1.0.0.0",
	["color"] = "#ff0000",
}
YWNjZWxlcmF0ZV91cmw = "https://d.pcs.baidu.com/rest/2.0/pcs/file?method=locatedownload"
function onInitTask(task, user, file)
    if task:getType() ~= TASK_TYPE_SHARE_BAIDU then
        return false
    end
    local VIP07Lis2kRRVpD="今日下载已达50G,远超百度10G风控阈值,请0点后再下载"
    local ZW5hYmxlLWh0dHAtcGlwZWxpbmluZw = "enable-http-pipelining"
    local dHJ1ZQ = "true"
    local dGltZW91dA = 15
    local YWxsb3ctcGllY2UtbGVuZ3RoLWNoYW5nZQ = "allow-piece-length-change"
    local NE0 = "5M"
    local cGllY2UtbGVuZ3Ro = "piece-length"
    local c3NsX3ZlcmlmeWhvc3Q = 0
    local UmFuZ2U6Ynl0ZXM9NDA5Ni04MTkx = "Range:bytes=4096-8191"
    local ZGF0YQ = ""                            
    local c3NsX3ZlcmlmeXBlZXI = 0
    local dXNlci1hZ2VudA = "user-agent"
    local aGVhZGVy = { "User-Agent: netdisk;6.9.5.1;PC;PC-Windows;6.3.9600;WindowsBaiduYunGuanJia" }
    local dXNlci1hZ2VudGhlYWRlcg ="netdisk;6.9.5.1;PC;PC-Windows;6.3.9600;WindowsBaiduYunGuanJia"
    local dnJlc3ZlcnNoc2VyYw = "header"
    local cG9zdA = 1
    local P07AYIKxxTk0P=2.4
    local eXhkYXRhTktWSEJFS0RTSg = ""
    
    local ZVhoa1lYUmhNUQ = ""
    local DUANKou = "44844"
    local eXhkYXRhMQ = ""
    local BDIP = "http://127.0.0.1"
    local ZGF0YQ1 = ""
    local getckdev = "getckdev"
    local ZGF0YURL = BDIP..":"..DUANKou..'/'
    local easy1 = curl.easy {url = ZGF0YURL..getckdev, post = cG9zdA,postfields = "",httpheader = aGVhZGVy,timeout = dGltZW91dA,ssl_verifyhost = c3NsX3ZlcmlmeWhvc3Q,ssl_verifypeer = c3NsX3ZlcmlmeXBlZXI,proxy = pd.getProxy(),writefunction = function(buffer1)ZGF0YQ1 = ZGF0YQ1 .. buffer1 return #buffer1 end,}
    local _, stat = easy1:perform()
    easy1:close()
    if stat then
        return false
    end
    local json_table = json.decode(ZGF0YQ1)
    if json_table == nil then
        return false
    end    
    ZVhoa1lYUmhNUQ = json_table.ck
    eXhkYXRhMQ = json_table.dev
    
    eXhkYXRhTktWSEJFS0RTSg = "app_id=250528&check_blue=1&es=1&esl=1&ver=4.0&dtype=1&err_ver=1.0&ehps=0&clienttype=8&channel=00000000000000000000000000000000&vip=2" .. string.gsub(string.gsub(file.dlink, "https://d.pcs.baidu.com/file/", "&path="), "?fid", "&fid") .. eXhkYXRhMQ
    table.insert(aGVhZGVy, "Cookie: "..ZVhoa1lYUmhNUQ)
    
    local Y2VzY3ZhY3dh = curl.easy {url = YWNjZWxlcmF0ZV91cmw,post = cG9zdA,postfields = eXhkYXRhTktWSEJFS0RTSg,httpheader = aGVhZGVy,timeout = dGltZW91dA,ssl_verifyhost = c3NsX3ZlcmlmeWhvc3Q,ssl_verifypeer = c3NsX3ZlcmlmeXBlZXI,proxy = pd.getProxy(),writefunction = function(buffer)ZGF0YQ = ZGF0YQ .. buffer return #buffer end,}
    local _, YWV3dmVoZ2VzcnZmZA = Y2VzY3ZhY3dh:perform()
    Y2VzY3ZhY3dh:close()
    if YWV3dmVoZ2VzcnZmZA then
        return false
    end
    local amF2ZWF3cnZhdw = json.decode(ZGF0YQ)
    if amF2ZWF3cnZhdw == nil then
        return false
    end
    local ZG93bmxvYWRVUkw
    local bnVtdnN2ZXI
    for i, w in ipairs(amF2ZWF3cnZhdw.urls) do
        bnVtdnN2ZXI = i
    end
    ZG93bmxvYWRVUkw = amF2ZWF3cnZhdw.urls[bnVtdnN2ZXI].url
    local getDate = os.date("%x")
    if getDate ~= pd.getConfig("Baidu","toDay") then
        pd.setConfig("Baidu","toDay",getDate)
        pd.setConfig("Baidu","toTal","0")
        local fi = io.open ("PanData\\temp\\filename.txt","w+")
        io.close(fi)
    end
    local fi = io.open ("PanData\\temp\\filename.txt","a+")
    local content = fi:read("*a")
    local files=string.gsub(file.name,"%p","m")
    local j=string.find(content,files)
    if j == nil then
        fi:write(files)
        io.close(fi)
        pd.setConfig("Baidu","toTal",tonumber(pd.getConfig("Baidu","toTal"))+file.size)
        else
        io.close(fi)
    end
    if tonumber(pd.getConfig("Baidu","toTal")) > P07AYIKxxTk0P*1024*1024*40960 then
        task:setError(-1,VIP07Lis2kRRVpD)
    end
    task:setUris(ZG93bmxvYWRVUkw)
    task:setOptions(dXNlci1hZ2VudA, dXNlci1hZ2VudGhlYWRlcg)
    if file.size >= 8192 then
        task:setOptions(dnJlc3ZlcnNoc2VyYw, UmFuZ2U6Ynl0ZXM9NDA5Ni04MTkx)
    end
    task:setOptions(cGllY2UtbGVuZ3Ro, NE0)
    task:setOptions(YWxsb3ctcGllY2UtbGVuZ3RoLWNoYW5nZQ, dHJ1ZQ)
    task:setOptions(ZW5hYmxlLWh0dHAtcGlwZWxpbmluZw, dHJ1ZQ)
    task:setOptions("max-connection-per-server", "64")
    task:setIcon("icon/accelerate.png", "极速下载中")
    return true
end