﻿local curl = require "lcurl.safe"
local json = require "cjson.safe"
script_info = {
    ["title"] = "FKBD加速2线",
    ["description"] = "fkbd",
    ["version"] = "fkbd出品",
    ["color"] = "#ff0000",
}
function request(url,header)
	local r = ""
	local c = curl.easy{
		url = url,
		httpheader = header,
		ssl_verifyhost = 0,
		ssl_verifypeer = 0,
		followlocation = 1,
		timeout = 30,
		proxy = pd.getProxy(),
		writefunction = function(buffer)
			r = r .. buffer
			return #buffer
		end,
	}
	local _, e = c:perform()
	c:close()
	return r
end
function onInitTask(task, user, file)
local header = {}
file.id = string.format("%d",file.id)
if task:getType() ~= TASK_TYPE_SHARE_BAIDU then
		table.insert(header,"User-Agent: netdisk")
		table.insert(header,"Cookie:"..user.cookie)
end
local locdata = "serverIpTiHuanWo/jiexi/v1/jiexi2?secretKey=secretKeyTiHuanWo&token=tokenTiHuanWo&data="
local data = ""

local requesturl=locdata.. pd.base64Encode(json.encode(file))
local c = curl.easy{
	url = requesturl,
	followlocation = 1,
	httpheader = header,
	timeout = 30,
	proxy = pd.getProxy(),
	writefunction = function(buffer)
		data = data .. buffer
		return #buffer
	end,
}
local _, e = c:perform()
c:close()

if e then
	task:setError(-1,"加速服务器连接失败，请检查您的网络是否正常")
	return true
end

local b = json.decode(data)
		
if b.code==200 then
local resData = pd.base64Decode(b.data)
local resJson = json.decode(resData)
task:setUris(resJson.durl)
task:setOptions("user-agent", resJson.dua)
if resJson.hra then
if file.size >= 8192 then
task:setOptions("header", resJson.rg)
end
end
task:setOptions("piece-length", resJson.pl)
task:setOptions("split", resJson.sp)
task:setOptions("allow-piece-length-change", resJson.ap)
task:setOptions("enable-http-pipelining", resJson.eh)
task:setOptions("max-connection-per-server", resJson.mc)
task:setIcon("icon/accelerate.png", "正在加速下载")
else
task:setError(b.code,b.data)
end
return true
end